//
//  ViewController.swift
//  animationsDemo
//
//  Created by Datta,M Kartikeya on 3/7/24.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imageViewOL: UIImageView!
    @IBOutlet weak var showMeOL: UIButton!
    @IBOutlet weak var happyOL: UIButton!
    @IBOutlet weak var sadOL: UIButton!
    @IBOutlet weak var angryOL: UIButton!
    @IBOutlet weak var shakeMeOL: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func viewDidAppear(_ animated: Bool) {
        // Keep all the componenets outside the view except show a button.
        imageViewOL.frame.origin.x = view.frame.width
        happyOL.frame.origin.x = view.frame.width
        sadOL.frame.origin.x = view.frame.width
        angryOL.frame.origin.x = view.frame.width
        shakeMeOL.frame.origin.x = view.frame.width
        
    }
    @IBAction func happyBtnClicked(_ sender: Any) {
        updateAndAnimate("happy")
    }
    @IBAction func sadBtnClicked(_ sender: Any) {
        updateAndAnimate("sad")
    }
    @IBAction func angryBtnClicked(_ sender: Any) {
        updateAndAnimate("angry")
    }
    @IBAction func shakeMeBtnClicked(_ sender: Any) {
        //increase the size of the image
        var width = imageViewOL.frame.width
        width += 40
        var height = imageViewOL.frame.height
        height += 40
        var x = imageViewOL.frame.origin.x
        x -= 20
        var y = imageViewOL.frame.origin.y
        y -= 20
        
        var largerFrame = CGRect(x: x, y: y, width: width, height: height)
        UIView.animate(withDuration: 2, delay: 0, usingSpringWithDamping: 0.05, initialSpringVelocity: 15, animations: {
            self.imageViewOL.frame = largerFrame
        })
    }
    @IBAction func showMeBtnClicked(_ sender: Any) {
        //Move all the components from outside of the view to centre of the view.
        UIView.animate(withDuration: 1, animations: {
            self.imageViewOL.center.x = self.view.center.x
            self.happyOL.center.x = self.view.center.x
            self.sadOL.center.x = self.view.center.x
            self.angryOL.center.x = self.view.center.x
            self.shakeMeOL.center.x = self.view.center.x
        })
        //disable the show button.
        showMeOL.isEnabled = false
    }
    func updateAndAnimate(_ image:String){
        //Making the current image as opaque(Alpha =0)
        UIView.animate(withDuration: 1, animations: {
            self.imageViewOL.alpha = 0
        })
        //Assign the new image with an animation and make it transparent(Alpha =1)
        UIView.animate(withDuration: 1, delay: 0.5, animations: {
            self.imageViewOL.alpha = 1
            self.imageViewOL.image = UIImage(named: image)
        })
    }
}

