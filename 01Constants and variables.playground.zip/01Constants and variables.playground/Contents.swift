import UIKit

var greeting = "Hello, playground"
var fruit = "Apple"
fruit = "Orange"
print(fruit)

let g = 9.18
print(g)
var lifespan : Int = 70
lifespan = lifespan + 20
print(lifespan)

var today = "Thursday"
print("Today is")
print(today)

var fruit1 = "grape"
var fruit2 = "banana"
print(fruit1, "_", fruit2)
print(10,10.5)
