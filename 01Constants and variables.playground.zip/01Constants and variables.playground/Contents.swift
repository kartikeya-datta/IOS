import UIKit

var greeting = "Hello, playground"
var fruit = "Apple"
fruit = "Orange"
print(fruit)

let g = 9.18
print(g)
var lifespan : Int = 70
lifespan = lifespan + 20
print(lifespan)

var today = "Thursday"
print("Today is")
print(today)

var fruit1 = "grape"
var fruit2 = "banana"
print(fruit1, "_", fruit2)
print(10,10.5)


//Declaration of variable
var mobileBrand = "Apple"
mobileBrand = "Samsung"
print(mobileBrand)
let pi = 3.14
print(pi)
//Explicit Declaration of Variable
var age : Int = 23
age = age * 2
print(age)
var aweMessage = "This is Superb!"
print(aweMessage)
print("aweMessage")
var course1 = "iOS"
var course2 = "Java"
print(course1,course2)
print(course1,"-",course2)
print(10,20,30)
print(12.5,15.5)
