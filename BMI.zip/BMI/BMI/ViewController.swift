//
//  ViewController.swift
//  BMI
//
//  Created by Datta,M Kartikeya on 3/26/24.
//

import UIKit

class ViewController: UIViewController {
    
    var height = 0.0
    var weight = 0.0
    var BMI = 0.0
    var image = ""
    var result = ""

    @IBOutlet weak var weightOL: UITextField!
    
    @IBOutlet weak var heightOL: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func CalculateBMI(_ sender: Any) {
        
        //Read the Height and weight and convert it into Double
        height = Double(heightOL.text!)!
        weight  = Double(weightOL.text!)!
        
        //Calculate BMI
        BMI = (703*weight)/(height*height)
        
        if BMI < 18.5{
            result = "Underweight"
            image = "UnderWeight"
        } else if BMI < 25.0 {
            result = "Normal"
            image = "Normal"
        }else if BMI < 30.0 {
            result = "Overweight"
            image = "OverWeight"
        }
        else{
            result = "Obese"
            image = "Obese"
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if(segue.identifier == "bmisegue"){
            let destination = segue.destination as! ResultViewController
            
            //Assigning view controller variables tro resultViewController
            destination.image = image
            destination.result = result
            destination.height = height
            destination.weight = weight
            destination.bmi = BMI
        }
    }
}

