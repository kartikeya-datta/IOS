import UIKit

var greeting = "Hello, playground"
var names = ["Ram":"Sita",  "Radhe":"Shyam", "Shiv":"Parwati"]
print(names)
print(names.count)
names["Krishn"] = "Draupadhi"
print(names)
names["Krishn"] = "Tulsai"
print(names)
names.removeValue(forKey: "Krishn")
print(names)
for(key, value) in names{
    print(key)
}
print()
for(key, values ) in names{
    print(values)
}
print()
for (key,values) in names
{
print("\(key) : \(values)")
}


//sets

print("\n\nsets\n")
var games : Set<String> = ["Football", "Cricket", "Volleball", "Tennis"]
print(games)
print(games.count)
print(games.contains("Tennis"))
games.insert("Badminton")
print(games)
games.remove("Cricket")
print(games)
var oddNumbers : Set<Int> = [0,1,3,5,7,9,11]
var evenNumbers : Set<Int> = [0,2,4,6,8,10,12]
var unionSet : Set<Int> = oddNumbers.union(evenNumbers)
print(unionSet.sorted())
var intersectionSet : Set<Int> = oddNumbers.intersection(evenNumbers)
print(intersectionSet.sorted())
var subtraction : Set<Int> = evenNumbers.subtracting(oddNumbers)
print(subtraction.sorted())
var symmDiffSet :Set<Int> =
oddNumbers.symmetricDifference(evenNumbers)
print(symmDiffSet.sorted())
print(oddNumbers.isSubset(of: evenNumbers))


//Array
print("\n\nArray\n")
var numbers:[Int] = [2,3,4]
print(numbers)
var emptyArray = [Int]()
print(emptyArray)
var programmingLanguages = ["Swift", "Java", "Python"]
print(programmingLanguages[0])
programmingLanguages[0] = "Java Script"
print(programmingLanguages[0])
print(programmingLanguages)

var names1:[String] = ["Oliver", "Elijah", "James"]
print("Before appending \(names1)")
names1.append("Masthan")
print("After appending \(names1)")
print("Before inserting \(names1)")
names1.insert("Benjamin", at: 2)
print("After inserting \(names1)")
print(names1.count)
names1.sort()
print("After sorting \(names1)")

