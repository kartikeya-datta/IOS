//
//  ViewController.swift
//  iHello2
//
//  Created by Sivadi,Sumanth Kumar on 1/23/24.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var NameOL: UITextField!
    
    @IBOutlet weak var AgeOL: UITextField!
    
    @IBOutlet weak var OutputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func GoBtn(_ sender: Any) {
        var name=NameOL.text!
        var age=AgeOL.text!
        OutputOL.text="Hey \(name), you are \(age) now !!"
    }
    
    
}

