//
//  ViewController.swift
//  Animations Demo
//
//  Created by Sivadi,Sumanth Kumar on 3/7/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageViewOL: UIImageView!
    
    @IBOutlet weak var big3OL: UIButton!
    
    @IBOutlet weak var narutoOL: UIButton!
    @IBOutlet weak var luffyOL: UIButton!
    @IBOutlet weak var ichigoOL: UIButton!
    @IBOutlet weak var vibrateOL: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
      //Keep all the components outside of the view except show me button
        
        imageViewOL.frame.origin.x = view.frame.width
        narutoOL.frame.origin.x = view.frame.width
        luffyOL.frame.origin.x = view.frame.width
        ichigoOL.frame.origin.x = view.frame.width
        vibrateOL.frame.origin.x = view.frame.width
        
    }

    @IBAction func narutoBtn(_ sender: Any) {
        updateandAnimate("Naruto.jpeg")
    }
    @IBAction func luffyBtn(_ sender: Any) {
        updateandAnimate("Luffy.jpeg")
    }
    @IBAction func ichigoBtn(_ sender: Any) {
        updateandAnimate("Ichigo.jpeg")
    }
    @IBAction func vibrateBtn(_ sender: Any) {
       
        //increase the size of the image
        var width=imageViewOL.frame.width
        width+=40
        var height=imageViewOL.frame.height
        height+=40
        
        var x=imageViewOL.frame.origin.x
        x-=20
        var y=imageViewOL.frame.origin.y
        y-=20
        
        
        var largerFrame=CGRect(x: x, y: y, width: width, height: height)
        
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {
            self.imageViewOL.frame=largerFrame
        })
    }
    @IBAction func big3Btn(_ sender: Any) {
        //Move all the components from outside of the view to the center of the view
        UIView.animate(withDuration: 1) {
            self.imageViewOL.center.x=self.view.center.x
            self.narutoOL.center.x=self.view.center.x
            self.luffyOL.center.x=self.view.center.x
            self.ichigoOL.center.x=self.view.center.x
            self.vibrateOL.center.x=self.view.center.x
        }
        
        //Disable the Big3 Button
        big3OL.isEnabled=false
    }
    
    func updateandAnimate(_ image:String){
        //Making the current image as opaque(alpha=0)
        UIView.animate(withDuration: 1, animations:{
            self.imageViewOL.alpha=0
        } )
        
        //Assign the new image with an animation and making it transparent(alpha=1)
        UIView.animate(withDuration: 1, delay: 0.5, animations: {
            self.imageViewOL.alpha=1
            self.imageViewOL.image=UIImage(named: image)
        })
        
    }
}

