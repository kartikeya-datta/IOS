//
//  ViewController.swift
//  Alphabet
//
//  Created by Sivadi,Sumanth Kumar on 1/30/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var inOL: UITextField!
    
    
    @IBOutlet weak var outOL: UILabel!
    
    
    @IBOutlet weak var imageOL: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func Button(_ sender: Any) {
        var alphabet = inOL.text!.lowercased()
        
        if (alphabet .contains("a")){
            outOL.text = "A for Apple"
            imageOL.image = UIImage(named: "Apple.jpeg")
        }
        else if(alphabet.contains("b")){
            outOL.text = "B for Ball"
            imageOL.image = UIImage(named: "Ball.jpeg")
        }
        else if(alphabet.contains("c")){
            outOL.text = "C for Cat"
            imageOL.image = UIImage(named: "Cat.jpeg")
        }else if(alphabet.contains("d")){
            outOL.text = "D for Dog"
            imageOL.image = UIImage(named: "Dog.jpeg")
        }else{
            outOL.text = "Next Class"
            imageOL.image = UIImage(named: "Last.jpeg")}
    }
    

}

