//
//  ViewController.swift
//  Temperature identifier
//
//  Created by Sivadi,Sumanth Kumar on 1/25/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func checkBtnClicked(_ sender: Any) {
        
        //Read the entered text and assign it to a variable
        //var temperature = inputOL.text!
        // Convert the String into Int
        var temperature = Int(inputOL.text!)
        
        //check for vowels using if statement
        if(temperature!>=60){
            //print the text message
            print("Its Hot outside 🥵 !")
            //assign the output to output label
            outputOL.text="Its Hot outside 🥵 !"
        }else{
            //print the text message
            print("Its Cold outside 🥶 !")
            //assign the output to output label
            outputOL.text="Its Cold outside 🥶 !"
        }
    }
        
    }
    


