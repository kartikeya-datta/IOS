//
//  ViewController.swift
//  Weather
//
//  Created by Sivadi,Sumanth Kumar on 1/30/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var inOL: UITextField!
    
    
    @IBOutlet weak var outOL: UILabel!
    
    
    @IBOutlet weak var imageOL: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func Button(_ sender: Any) {
        // Read the input Temperature
        var temperature = Int(inOL.text!)
        
        if (temperature!>=60){
            outOL.text = "It's Hot! 🥵"
            imageOL.image = UIImage(named: "hot.jpeg")
        }
        else{
            outOL.text = "It's Cold! 🥶"
            imageOL.image = UIImage(named: "cold.jpeg")
        }
    }
    
}

