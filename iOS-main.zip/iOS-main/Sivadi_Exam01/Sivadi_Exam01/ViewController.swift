//
//  ViewController.swift
//  Sivadi_Exam01
//
//  Created by Sivadi,Sumanth Kumar on 2/15/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var idOL: UITextField!
    @IBOutlet weak var fbgOL: UITextField!
    @IBOutlet weak var outOL: UILabel!
    @IBOutlet weak var imageOL: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func CalculateBtn(_ sender: Any) {
        let patientID = idOL.text!
        let fbgValue = Double(fbgOL.text!)
        let HbA1c = 2.6 + 0.03*fbgValue!
        if(HbA1c < 4.70){
            outOL.text = ("Patient ID:\(patientID) \nFBG Level:\(fbgValue!)(mg/dl) \nHbA1c(%):\(String(format: "%.2f",HbA1c))% \nResult:Hypoglycemia \nHealth Tip:Eat food on time 🍎")
            imageOL.image = UIImage(named: "hypoglycemia.png")
        }
        else if(HbA1c >= 4.70 && HbA1c < 5.59){
            outOL.text = ("Patient ID:\(patientID) \nFBG Level:\(fbgValue!)(mg/dl) \nHbA1c(%):\(String(format: "%.2f",HbA1c))% \nResult:Normal \nHealth Tip:You are doing great 👍")
            imageOL.image = UIImage(named: "normal.png")
        }
        else if(HbA1c >= 5.60 && HbA1c < 6.35){
            outOL.text = ("Patient ID:\(patientID) \nFBG Level:\(fbgValue!)(mg/dl) \nHbA1c(%):\(String(format: "%.2f",HbA1c))% \nResult:Pre-Diabetes \nHealth Tip:You should work on your diet and maintain workout 🏋️")
            imageOL.image = UIImage(named: "pre-diabetes.png")
        }
        else{
            outOL.text = ("Patient ID:\(patientID) \nFBG Level:\(fbgValue!)(mg/dl) \nHbA1c(%):\(String(format: "%.2f",HbA1c))% \nResult:Diabetes \nHealth Tip:Consult doctor for medication 🩺")
            imageOL.image = UIImage(named: "diabetes.png")
        }
    }
    
    @IBAction func ResetBtn(_ sender: Any) {
        idOL.text=""
        fbgOL.text=""
        outOL.text=""
        imageOL.image = nil
        
    }
    
}

