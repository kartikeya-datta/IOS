//
//  ViewController.swift
//  VowelTester
//
//  Created by Sivadi,Sumanth Kumar on 1/25/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func CheckBtnClicked(_ sender: Any) {
        //Read the entered text and assign it to a variable
        var input = inputOL.text!
        
        //check for vowels using if statement
        if(input.contains("a") ||
           input.contains("e") ||
           input.contains("i") ||
           input.contains("o") ||
           input.contains("u")){
    //print the text message
print("\(input) contains the vowel 👍🏻")
    //assign the output to output label
outputOL.text="\(input) contains the vowel 👍🏻"
}else{
    //print the text message
print("\(input) does not contain the vowels👎🏻")
    //assign the output to output label
outputOL.text="\(input) does not contain the vowels👎🏻"
}
        
    }
    
}

