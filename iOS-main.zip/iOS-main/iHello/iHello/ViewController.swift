//
//  ViewController.swift
//  iHello
//
//  Created by Sivadi,Sumanth Kumar on 1/23/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitBtnClicked(_ sender: Any) {
        //Read the input
        var ip=inputOL.text!
        //String interpolate the input with "Hello",
        //Assign it to the display or to the output label
        outputOL.text="Hello,\(ip)"
    }
    
}

