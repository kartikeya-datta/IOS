//
//  ViewController.swift
//  Sivadi_PracticeExam01
//
//  Created by Sivadi,Sumanth Kumar on 2/13/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var InFeetOL: UITextField!
    
    @IBOutlet weak var InInchesOL: UITextField!
    
    @IBOutlet weak var InWeightOL: UITextField!
    
    @IBOutlet weak var OutOL: UILabel!
    
    @IBOutlet weak var ImageOL: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func CalculateBtn(_ sender: Any) {
    }
    
        let feet = Double(InFeetOL.text!)
        let inches = Double(InInchesOL.text!)
        let height = feet!*12 + inches!
        let weight = Double(InWeightOL.text!)
        let BMI = 703*(weight!/(height*height))
        if(BMI < 18.5){
            OutOL.text = ("Your Body Mass Index is \(String(format: "%.1f",(BMI))). \nThis is considered undereweight.")
            ImageOL.image = UIImage(named: "underWeight.jpeg")
        }
        else if(BMI >= 18.5 && BMI < 25){
            OutOL.text = ("Your Body Mass Index is \(String(format: "%.1f",(BMI))). \nThis is considered normal 👍🏻.")
            ImageOL.image = UIImage(named: "normal.jpeg")
        }
        else if(BMI >= 25.0 && BMI < 30){
            OutOL.text = ("Your Body Mass Index is \(String(format: "%.1f",(BMI))). \nThis is considered Overweight.")
                        ImageOL.image = UIImage(named: "overWeight.jpeg")
        }
        else {
            OutOL.text = ("Your Body Mass Index is \(String(format: "%.1f",(BMI))). \nThis is considered Obesity.")
                        ImageOL.image = UIImage(named: "obese.jpeg")
        }
    }

