//
//  ViewController.swift
//  Course Display App
//
//  Created by Sivadi,Sumanth Kumar on 2/22/24.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imageViewOL: UIImageView!
    @IBOutlet weak var crsNumOL: UILabel!
    @IBOutlet weak var crsTitleOL: UILabel!
    @IBOutlet weak var semesterOL: UILabel!
    
    @IBOutlet weak var prevBtnOL: UIButton!
    @IBOutlet weak var nextBtnOL: UIButton!
    
    let courses = [["img01",  "44444", "Network Security", "Fall"],
                   ["img02",  "44555", "iOS", "Spring"],
                   ["img03",  "44666", "Data Streaming", "Summer"],
                   ["img04",  "44777", "Internet Of Things", "Fall"]]
    
    var imgNum=0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Do any Additional setup for loading the view
        //Prev Button Should be Disabled
        prevBtnOL.isEnabled=false;
        
        // Do any additional setup after loading the view.
        imageViewOL.image=UIImage(named: courses[0][0])
        crsNumOL.text=courses[0][1]
        crsTitleOL.text=courses[0][2]
        semesterOL.text=courses[0][3]
    }
    @IBAction func prevBtn(_ sender: Any) {
        //Next  button should be Enabled
        nextBtnOL.isEnabled=true;
        
        //Decrement the image Number
        imgNum=imgNum - 1;
        
        //Updating the course details
        updateCourse(imgNum)
        
        //Once the user reach the begin of array, the prev button should be disabled
        if(imgNum==0){
            prevBtnOL.isEnabled=false;
        }

    }
    
    @IBAction func nextBtn(_ sender: Any) {
        
        //Prev button should be enabled
        prevBtnOL.isEnabled = true;
        
        //Increment the image number
        imgNum=imgNum + 1;
        
        //Updating the course details
        updateCourse(imgNum)

        //Once the user reach the end of array, the next button should be disabled
        if(imgNum == courses.count-1){
            nextBtnOL.isEnabled = false;
        }
        
    }
    
    func updateCourse(_ imgNum:Int){
        imageViewOL.image=UIImage(named: courses[imgNum][0])
        crsNumOL.text=courses[imgNum][1]
        crsTitleOL.text=courses[imgNum][2]
        semesterOL.text=courses[imgNum][3]
    }
    


}

