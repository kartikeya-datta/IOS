//
//  ViewController.swift
//  Currency App
//
//  Created by Sivadi,Sumanth Kumar on 2/8/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var inOL: UITextField!
    
    @IBOutlet weak var outOL: UILabel!
    
    @IBOutlet weak var imageOL: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func Btn(_ sender: Any) {
        var currency = Int(inOL.text!)
        var convertyedCurrency = currency * 3.26;
        
        if (currency .contains("a")){
            outOL.text = convertyedCurrency
            imageOL.image = UIImage(named: "Apple.jpeg")
    }
    

}

