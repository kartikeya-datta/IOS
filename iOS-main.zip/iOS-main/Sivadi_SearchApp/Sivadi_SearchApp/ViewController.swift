//
//  ViewController.swift
//  Sivadi_SearchApp
//
//  Created by Sivadi,Sumanth Kumar on 3/19/24.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var resultImage: UIImageView!
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var SearchBtnOutlet: UIButton!
    @IBOutlet weak var PrevBtnOutlet: UIButton!
    @IBOutlet weak var ResetBtnOutlet: UIButton!
    @IBOutlet weak var NextBtnOutlet: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func searchButtonAction(_ sender: Any) {
    }
    @IBAction func ShowPrevImagesBtn(_ sender: Any) {
    }
    @IBAction func ResetBtn(_ sender: Any) {
    }
    @IBAction func ShowNextImagesBtn(_ sender: Any) {
    }
    
}

