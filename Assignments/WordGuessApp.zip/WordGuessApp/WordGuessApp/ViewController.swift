//
//  ViewController.swift
//  WordGuessApp
//
//  Created by Datta,M Kartikeya on 2/27/24.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var displayLabelOL: UILabel!
    @IBOutlet weak var hintLabelOL: UILabel!
    @IBOutlet weak var textOL: UITextField!
    @IBOutlet weak var checkBtnOL: UIButton!
    @IBOutlet weak var statusLabelOL: UILabel!
    @IBOutlet weak var playAgainOL: UIButton!
    
    
    var words = [["APPLE", "Fruit"],
              ["CAT", "Animal"],
              ["SEARCH", "To Find"],
              ["MACBOOK", "Apple device"]]
     
     var count = 0;
     var word = ""
     var lettersGuessed = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Check button should  be disabled initially
        checkBtnOL.isEnabled = false
        //assigning a word from the array of words
        word = words[count][0]
        displayLabelOL.text = ""
        //Populate the display label with the underscores. Number of underscores is equal to the number of characters in the word.
        updateUnderscores();
        //Get the first hint from the array
        hintLabelOL.text = "Hint: "+words[count][1]
        //Clear the status label intially.
        statusLabelOL.text = ""
    }

    @IBAction func TextChange(_ sender: Any) {
        //Read the data from the text field
        var text = textOL.text!
        //Consider only the last character by calling textEntered.last and trimming the white spaces.
        text = String(text.last ?? " ").trimmingCharacters(in: .whitespaces)
        textOL.text = text
        //Check whether the entered text is empty or not to enable check button.
        if text.isEmpty{
            checkBtnOL.isEnabled = false
        }
        else{
            checkBtnOL.isEnabled = true
        }
    }
    
    @IBAction func CheckBTN(_ sender: Any) {
        //Get the text from the text field.
        let character = textOL.text!
        //Replace the guessed letter if the letter is part of the word.
        lettersGuessed = lettersGuessed + character
         var revealedWord = ""
        for letter in word{
            if lettersGuessed.contains(letter){
                revealedWord += "\(letter)"
            }
            else{
                revealedWord += "_ "
            }
        }
        //Assigning the word to displaylabel after a guess
        displayLabelOL.text = revealedWord
        textOL.text = ""
        //If the word is guessed correctly, we are enabling play again button and disabling the check button.
        if displayLabelOL.text!.contains("_") == false{
            playAgainOL.isHidden = false;
                    checkBtnOL.isEnabled = false;
                }
                checkBtnOL.isEnabled = false
    }
    
    @IBAction func PlayAgainBTN(_ sender: Any) {
        //Reset the button to disable initially.
        playAgainOL.isHidden = true
        //clear the label
        lettersGuessed = ""
        count += 1
        //if count reaches the end of the array (all the words are guessed sucessfully), then print Congratualtions in the status label.
        if count == words.count{
                    
                    statusLabelOL.text = "Congruations! You are done with the game!"
                    //clearing the labels.
                    displayLabelOL.text = ""
                    hintLabelOL.text = ""
                }
                else{
                    //fetch the next word from the array
                    word = words[count][0]
                    //fetch the hint related to the word
                    hintLabelOL.text = "Hint: "
                    hintLabelOL.text! += words[count][1]
                    //Enabling the check button.
                    checkBtnOL.isEnabled = true
                    
                    displayLabelOL.text = ""
                    updateUnderscores()
                }
    }
    
    func updateUnderscores(){
          for letter in word{
              displayLabelOL.text! += "_ "
          }
      }
}

