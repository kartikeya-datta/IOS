//
//  ViewController.swift
//  Datta_Assignment02
//
//  Created by Karthikeya on 1/30/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameOutlet: UITextField!
    @IBOutlet weak var billAmountOutlet: UITextField!
    @IBOutlet weak var tipPercentageOutlet: UITextField!
    @IBOutlet weak var dateOutlet: UIDatePicker!
    
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var billAmountLabel: UILabel!
    @IBOutlet weak var tipAmountLabel: UILabel!
    @IBOutlet weak var totalAmountLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func SubmitBTN(_ sender: UIButton) {
        let billAmnttxt = billAmountOutlet.text!
        let tipPcttxt = tipPercentageOutlet.text!
        guard let billAmt = Float(billAmnttxt),
                  let tipPct = Float(tipPcttxt) else {
                // Handle the case where conversion fails
                return
            }
        let datetime = dateOutlet.date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM-dd-yyyy HH:mm:ss"
        dateLabel.text = dateFormatter.string(from: datetime)
        nameLabel.text = "Name: \(nameOutlet.text!)"
        billAmountLabel.text = "Bill Amount: $\(billAmt)"
        tipAmountLabel.text = "Tip Amount: $\(String(format: "%.2f", (tipPct*billAmt)/100))"
        let totalamount = String(format: "%.2f", (billAmt + (tipPct*billAmt)/100))
        
        totalAmountLabel.text = "Total Amount: $\(totalamount)"
    }
    @IBAction func ResetBTN(_ sender: UIButton) {
        nameOutlet.text = ""
        billAmountOutlet.text = ""
        tipPercentageOutlet.text = ""
        dateLabel.text = ""
        nameLabel.text = ""
        billAmountLabel.text = ""
        tipAmountLabel.text = ""
        totalAmountLabel.text = ""
    }
    
}

