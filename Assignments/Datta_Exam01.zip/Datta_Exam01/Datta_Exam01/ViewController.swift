//
//  ViewController.swift
//  Datta_Exam01
//
//  Created by Datta,M Kartikeya on 2/15/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var PatientIDOL: UITextField!
    @IBOutlet weak var FBGOL: UITextField!
    @IBOutlet weak var outputOL: UILabel!
    @IBOutlet weak var imageOL: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func Calculating(_ sender: Any) {
        let PatientID = PatientIDOL.text!
        let FBG = Double(FBGOL.text!)
        let HbA1c = 2.6 + 0.03*FBG!
        if(HbA1c < 4.70){
            outputOL.text = "Patient ID : \(PatientID)\nFBG Level : \(FBG!) (mg/dl)\nHbA1c(%) : \(String(format: "%.2f",HbA1c)) %\nResult : Hypoglycemia\nHealth Tip: Eat food on time 🍎"
            imageOL.image = UIImage(named: "hypoglycemia.png")
        }
        else if(HbA1c >= 4.70 && HbA1c <= 5.59){
            outputOL.text = "Patient ID : \(PatientID)\nFBG Level : \(FBG!) (mg/dl)\nHbA1c(%) : \(String(format: "%.2f",HbA1c)) %\nResult : Normal\nHealth Tip: You are doing great 👍"
            imageOL.image = UIImage(named: "normal.png")
        }
        else if(HbA1c >= 5.60 && HbA1c <= 6.35){
            outputOL.text = "Patient ID : \(PatientID)\nFBG Level : \(FBG!) (mg/dl)\nHbA1c(%) : \(String(format: "%.2f",HbA1c)) %\nResult : Pre-Diabetes\nHealth Tip: You should work on your diet and maintain workout 🏋️"
            imageOL.image = UIImage(named: "pre-diabetes.png")
        }
        else {
            outputOL.text = "Patient ID : \(PatientID)\nFBG Level : \(FBG!) (mg/dl)\nHbA1c(%) : \(String(format: "%.2f",HbA1c)) %\nResult : Diabetes\nHealth Tip: Consult doctor for medication 🩺"
            imageOL.image = UIImage(named: "diabetes.png")
        }
    }
    @IBAction func Reset(_ sender: Any) {
        outputOL.text = ""
        PatientIDOL.text = ""
        FBGOL.text = ""
        imageOL.image = nil
    }
    
}

