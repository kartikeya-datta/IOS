//
//  ViewController.swift
//  MoviesAt
//
//  Created by Karthikeya on 2/27/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageviewOL: UIImageView!
    @IBOutlet weak var titleOL: UILabel!
    @IBOutlet weak var directorOL: UILabel!
    @IBOutlet weak var showOL: UILabel!
    @IBOutlet weak var previousOL: UIButton!
    @IBOutlet weak var nextOL: UIButton!
    
    
    let movies = [["img01","Khaleja","Trivikram Srinivas","Morning"],
                ["img02","Varsham","Sobhan","Noon"],
                ["img03","Darling","A. Karunakaran","Evening"],
                ["img04","Mr. Perfect","Dasaradh","Night"]]
    
    var imgNum = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        previousOL.isEnabled = false;
        //disply 1st movie
        imageviewOL.image = UIImage(named:movies[0][0])
        titleOL.text = movies[0][1]
        directorOL.text = movies[0][2]
        showOL.text = movies[0][3]
    }
    @IBAction func PreviousBTN(_ sender: Any) {
        nextOL.isEnabled = true;
        imgNum -= 1;
        updateContents(imgNum)
        if(imgNum == 0){
            previousOL.isEnabled = false;
        }
    }
    
    @IBAction func NextBTN(_ sender: Any) {
        //previous btn should be enabled
        previousOL.isEnabled = true;
        //increment
        imgNum += 1;
        //updating movie details
        updateContents(imgNum)
        //next button should be disabled once u reach
        if(imgNum == movies.count - 1){
            nextOL.isEnabled = false;
        }
    }
    func updateContents(_ imageNumber:Int){
        imageviewOL.image = UIImage(named: movies[imageNumber][0])
        titleOL.text = movies[imageNumber][1]
        directorOL.text = movies[imageNumber][2]
        showOL.text = movies[imageNumber][3]
    }
    
}

