//
//  ViewController.swift
//  Datta_Exam03
//
//  Created by Datta,M Kartikeya on 4/18/24.
//

import UIKit

class DattaViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return animalsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = dattaTVOL.dequeueReusableCell(withIdentifier: "dattaCell", for: indexPath)
        //Assign the data into the cell
        cell.textLabel?.text = "\(animalsArray[indexPath.row].name!)"
        return cell
    }
    
    var imageName: UIImage?
    
    @IBOutlet weak var dattaTVOL: UITableView!
    
var animalsArray = animals
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        dattaTVOL.delegate = self
        dattaTVOL.dataSource = self
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "DattaDescriptionSegue"{
            let destination = segue.destination as!  DattaAnimalController
            
            if let selectedIndexPath = dattaTVOL.indexPathForSelectedRow {
                let selectedContact = animalsArray[selectedIndexPath.row]
                if let name = selectedContact.name, let info = selectedContact.information {
                    destination.animal = name
                    destination.information = info
                    imageName = selectedContact.imageName
                    destination.imageName = imageName
                }
            }

        }
    }

}

