//
//  DattaAnimalController.swift
//  Datta_Exam03
//
//  Created by Datta,M Kartikeya on 4/18/24.
//

import UIKit

class DattaAnimalController: UIViewController {
    @IBOutlet weak var imageViewOL: UIImageView!
    
    @IBOutlet weak var nameOL: UILabel!
    
    @IBOutlet weak var descriptionOL: UITextView!
    
    var animal = ""
    var information = ""
    var imageName : UIImage?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        imageViewOL.image = imageName
        nameOL.text = animal
        descriptionOL.text = information
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
