import UIKit

var greeting = "Hello, playground"
print(greeting)
print("Paisa hi Pisa! hehehehe")

var progLang = "Java";
print("My favorite programming language is \(progLang)")
print("My favorite programming language is" + progLang)

print("""
      Hello
      world!
""")
print("Hello All,\rWelcome to swift programming")

//Class-2 18Jan

print("Datta, 23, 5.6")
var favColour = "Orange"
print("My favorite colour is \(favColour)")
var age = 23
print("My age is \(age) by march 24 I would be \(age+1)")
print("""
      Hello
      world!
""")
print("Hello All,\rWelcome to swift programming")
let welcomemessage : String = "Hello World🫡"
print(welcomemessage, "All")
// var, let, print statements, Data type

print("Welcome to Swift Programming")
print("Fall 2021")
print("*************")
print("Welcome to Swift Programming" , terminator : "-" )
print("Fall 2021")

print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is")
print(1,2,3,4,5,6, separator: "-")
print("M","Kartikeya","Datta", separator: "_")
