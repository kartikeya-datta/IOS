import UIKit

var greeting = "Hello, playground"
print("Paisa hi Pisa! hehehehe")
