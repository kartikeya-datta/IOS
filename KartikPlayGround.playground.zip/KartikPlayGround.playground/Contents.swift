import UIKit

var greeting = "Hello, playground"
print(greeting)
print("Paisa hi Pisa! hehehehe")

var progLang = "Java";
print("My favorite programming language is \(progLang)")
print("My favorite programming language is" + progLang)

var age = 23
print("My age is \(age) by march 24 I would be \(age+1)")
