//
//  ResultViewController.swift
//  EMICalculator
//
//  Created by Datta,M Kartikeya on 4/9/24.
//

import UIKit

class ResultViewController: UIViewController {
   
    var loanType = ""
    var loanAmount = ""
    var interestRate = ""
    var monthlyEMIPayment = 0.0
    var image = ""
    
    @IBOutlet weak var loanTypeOL: UILabel!
    
    @IBOutlet weak var loanAmountOL: UILabel!
    
    @IBOutlet weak var interestRateOL: UILabel!
    
    @IBOutlet weak var monthlyEMIOL: UILabel!
    
    
    @IBOutlet weak var imageVieewOL: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageVieewOL.image =  UIImage(named:image)
        loanTypeOL.text = loanType
        loanAmountOL.text = loanAmount
        interestRateOL.text = "\(interestRate)%"
        monthlyEMIOL.text = String(format: "%.2f", monthlyEMIPayment)
        
        // Do any additional setup after loading the view.
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
