//
//  ResultViewController.swift
//  EMICalculator
//
//  Created by Datta,M Kartikeya on 4/9/24.
//

import UIKit

class ResultViewController: UIViewController {
    
    @IBOutlet weak var loanTypeOL: UILabel!
    
    @IBOutlet weak var loanAmountOL: UILabel!
    
    @IBOutlet weak var interestRateOL: UILabel!
    
    @IBOutlet weak var monthlyEMIOL: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageViewOL.image = UIImage(named:image)
        tempOL.text = String("Temperature is \(temperature)")
        resultOL.text = String(result)

        // Do any additional setup after loading the view.
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
