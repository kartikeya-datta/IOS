//
//  profileViewController.swift
//  Datta_PracticeExam03
//
//  Created by Datta,M Kartikeya on 4/16/24.
//

import UIKit

class profileViewController: UIViewController {

    
    var initials = ""
    var phoneNumber = ""
    @IBOutlet weak var initialsOL: UILabel!
    
    @IBOutlet weak var phoneNumberOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initialsOL.text = "Initilas: \(initials)"
        phoneNumberOL.text = "Phone Number: \(phoneNumber)"
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
