//
//  ViewController.swift
//  Datta_PracticeExam03
//
//  Created by Datta,M Kartikeya on 4/16/24.
//

import UIKit

class contacts{
        var FirstName : String?
        var LastName : String?
        var PhoneNumber : String?
        
        init(FirstName: String, LastName: String, PhoneNumber: String){
            self.FirstName = FirstName
            self.LastName = LastName
            self.PhoneNumber = PhoneNumber
        }
    }

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contactsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = TableViewOL.dequeueReusableCell(withIdentifier: "contactCell", for: indexPath)
        //Assign the data into the cell
        cell.textLabel?.text = "\(contactsArray[indexPath.row].FirstName!) \(contactsArray[indexPath.row].LastName!)"
        return cell
    }
    
    
    var contactsArray = [contacts]()
    var initials = ""
    var phoneNumber = ""
    
    @IBOutlet weak var TableViewOL: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        TableViewOL.delegate = self
        TableViewOL.dataSource = self
        
        let n1 = contacts(FirstName: "Kartikeya", LastName: "Datta", PhoneNumber: "6605280578")
           contactsArray.append(n1)
           
        let n2 = contacts(FirstName: "Sumant", LastName: "Kumar", PhoneNumber: "6605280345")
           contactsArray.append(n2)
           
        let n3 = contacts(FirstName: "Sri", LastName: "Vasavi", PhoneNumber: "6605280011")
           contactsArray.append(n3)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "ContactSegue"{
            let destination = segue.destination as!  profileViewController
            
            if let selectedIndexPath = TableViewOL.indexPathForSelectedRow {
                let selectedContact = contactsArray[selectedIndexPath.row]
                destination.initials = "\(selectedContact.FirstName?.first ?? "?")\(selectedContact.LastName?.first ?? "?")"
                destination.phoneNumber = selectedContact.PhoneNumber ?? ""
            }
        }
    }

}

