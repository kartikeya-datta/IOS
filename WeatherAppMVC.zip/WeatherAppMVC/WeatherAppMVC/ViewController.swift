//
//  ViewController.swift
//  WeatherAppMVC
//
//  Created by Datta,M Kartikeya on 3/21/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textOL: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

