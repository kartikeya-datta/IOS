//
//  ViewController.swift
//  WeatherAppMVC
//
//  Created by Sumanth Kumar on 3/21/24.
//

import UIKit

class HomeViewController: UIViewController {
    @IBOutlet weak var temperatureOL: UITextField!
    
    var result = ""
    var image = ""
    var temperature:Double = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func checkBtn(_ sender: Any) {
        //Read temperature value and assign it to a variable, also convert to double
        temperature = Double(temperatureOL.text!)!
        //check the weather
        if (temperature>40){
            result="Its Hot"
            image="Hot"
        }else{
            result="Its Cold"
            image="Cold"
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //know the identifier
        let transition = segue.identifier
        //set the destination
        if(transition == "resultSegue"){
            let destination = segue.destination
            as! ResultViewController
            //assign values to the destination variables
            destination.image = image
            destination.result = result
            destination.temperature = temperature
        }
    }
    
}

