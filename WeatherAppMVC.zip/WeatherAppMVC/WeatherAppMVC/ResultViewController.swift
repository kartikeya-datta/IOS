//
//  ResultViewController.swift
//  WeatherAppMVC
//
//  Created by Sumanth Kumar on 3/21/24.
//

import UIKit

class ResultViewController: UIViewController {
    
    var result = ""
    var image = ""
    var temperature:Double = 0.0
    @IBOutlet weak var tempOL: UILabel!
    @IBOutlet weak var resultOL: UILabel!
    
    @IBOutlet weak var imageViewOL: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        //assign the
        imageViewOL.image = UIImage(named:image)
        tempOL.text = String("Temperature is \(temperature)")
        resultOL.text = String(result)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
