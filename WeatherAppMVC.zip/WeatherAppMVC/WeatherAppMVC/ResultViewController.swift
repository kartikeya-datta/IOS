//
//  ResultViewController.swift
//  WeatherAppMVC
//
//  Created by Datta,M Kartikeya on 3/21/24.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var imageViewOL: UIImageView!
    @IBOutlet weak var tempOL: UILabel!
    @IBOutlet weak var resultOL: UILabel!
    
    var image = ""
    var temperature:Double = 0.0
    var result = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //Know the identifier
        let transition = segue.identifier
        // Set the destination
        if(transition == "resultSegue"){
            let destination = segue.destination
            as! ResultViewController
            // Assign values to the destination variables
            destination.image = image
            destination.result = result
            destination.temperature = temperature
        }
    }
}
